# -*- coding: utf-8 -*-
"""
Created on Wed Jan 18 22:08:42 2023

@author: USER
"""

#%%
number_1= int(input("enter the first number:"))
number_2= int(input("enter the second number:"))
if number_1 >0:
    print('first number is positive')
    if number_2 >0:
        print("The computation results are:")
        print(number_1, '+',number_2,"=",number_1 + number_2)
        print(number_1, '-',number_2,"=",number_1 - number_2)
        print(number_1, 'x',number_2,"=",number_1 * number_2)
        print(number_1, '/',number_2,"=",number_1 / number_2)
elif number_1 <0:
    print("First number is negative please input a positive number")
    number_1= int(input("enter the first number:"))
    if number_2 >0:
            print("The computation results are:")
            print(number_1, '+',number_2,"=",number_1 + number_2)
            print(number_1, '-',number_2,"=",number_1 - number_2)
            print(number_1, 'x',number_2,"=",number_1 * number_2)
            print(number_1, '/',number_2,"=",number_1 / number_2)
elif number_2 < 0:
    print("Second number is negative please input a positive number")
    number_2= int(input("enter the second number:"))
    if number_1 >0:
        print('first number is positive')
        if number_2 >0:
            print("The computation results are:")
            print(number_1, '+',number_2,"=",number_1 + number_2)
            print(number_1, '-',number_2,"=",number_1 - number_2)
            print(number_1, 'x',number_2,"=",number_1 * number_2)
            print(number_1, '/',number_2,"=",number_1 / number_2)
else:
    print("invalid input; please type in a positive number for both inputs")
    number_1= int(input("enter the first number:"))
    number_2= int(input("enter the second number:"))
#%%
try: 
    first_number = int(input("Enter first number: "))
    second_number = int(input("Enter second number: "))
except ValueError: 
    print("Please enter only numeric number")
    first_number = int(input("Enter first number: "))
    second_number = int(input("Enter second number: "))
if(first_number > 0 and second_number > 0):
    print(first_number + second_number)
    print(first_number - second_number)
    print(first_number * second_number)
    print(first_number / second_number)  
else:
    print("Please enter only positive number")
    first_number = int(input("Enter first number: "))
    second_number = int(input("Enter second number: "))    
    print(first_number + second_number)
    print(first_number - second_number)
    print(first_number * second_number)
    print(first_number / second_number)
 #%%
NAME = input("What is your name?")
to_continue = input("Do you want to play y/n?:")
if to_continue == "y":
    play = input("What to play?\n [C] Chess \n [P] Pokemon")
    if play == "p":
        print("Let's go and catch poke.")
    elif play == "c":
        print("I'll play chess with you")
else: 
    print("Good bye")
#%%
print("Welcome to forex calculator")
print("""
      SGD to USD: 0.73829
      SGD to MYR: 3.05657
      SGD to EUR: 0.66323
      SGD to GBP : 0.55172
      SGD to AUD: 1.07305
      """)
USD = 0.73829
MYR = 3.05657
EUR = 0.66323
GBP = 0.55172
AUD = 1.07305
currency= str(input("Please input the currency you wish to convert USD,GBP:"))
sgd_value=float(input("please input the amount to exchange:"))
if(currency == "USD"):
    if(sgd_value<=5000):
        print("The equivalent amount is USD", USD * sgd_value * 0.99)
    else:
        print("The equivalent amount is USD", USD * sgd_value * 0.995)
elif(currency == "MYR"):
     if(sgd_value <= 5000):
        print("The equivalent amount is MYR", MYR * sgd_value * 0.99)
     else:
        print("The equivalent amount is MYR", MYR * sgd_value * 0.995)
elif(currency == "EUR"):
     if(sgd_value <= 5000):
        print("The equivalent amount is EUR", EUR * sgd_value * 0.99)
     else:
        print("The equivalent amount is EUR", EUR * sgd_value * 0.995)
elif(currency == "GBP"):
    if(sgd_value <= 5000):
        print("The equivalent amount is GBP", GBP * sgd_value * 0.99)
    else:
        print("The equivalent amount is GBP", GBP * sgd_value * 0.995)
elif(currency == "AUD"):
    if(sgd_value <= 5000):
        print("The equivalent amount is AUD", AUD * sgd_value * 0.99)
    else:
        print("The equivalent amount is AUD", AUD * sgd_value * 0.995)

else:
    print("currency asked not available")
    
        
        
        
        
        
#%%
principal= float(input("please type in the principal amt:"))
years= int(input('How many years would you like to invest:'))
print(f"At a yearly interest rate of 1.0%, you will receive {principal*(1+(0.01)*years)} if you invest {principal} now")
#%%
current_asset = 600000
current_liability = 46000
current_ratio = current_asset / current_liability
net_income = 1200000
total_share = 6150000
eps = net_income / total_share
print("The current ratio is ", current_ratio)
print("The EPS is ", eps)

#%% SEMINAR 2 NOTES
x= 9
y= 5 
print("division", 9/5)
print("integer division",9//5)
print("remainder division",9%5)

#division 1.8
#integer division 1
#remainder division 4
#PEMDAS similar to bodmas
#PEMDAS= Paranthesis,exponential,multi,division,addition,subtract
#augmented assignment operators: "=, +=, -=, *=, /=,**=,%=,//="
import math import sqrt
print(math.sqrt(144)) #will lead to error
# NameError: name math not defined
#correct order would be to import filename and add.sqrt(function) in the line
#e.g
from math import * 
#if file.py is named as math
print(math.sqrt(144))

#if variable from the import have same name 
CHECK HOW TO DO THIS FROM SLIDES AND GOOGLE ASK AROUND
#%%
x=400
# AND Operator = multiplication

0 x 0=>0
0 x 1=>0
1 x 0=>0
1 x 1=>1
#OR operator = addition
0 + 0=>0
0 + 1=>1
1 + 0=>1
1 + 1=>1
#%%
x=100
if (x<=100) and (x<=20) or (x>50):
    print("you are gay")
elif x>300:
    print("you are sus")
else:
    print("you are not gay")

#in a chain if there is a and statement we read that first
#e.g if true or false and false
# will be true
#if true and false and false
#will be false
#indentation error every block must follow the same marginal indentation
#syntax error usually the line quoted, the error occurs in prev line
#runtime error happens when running e.g type error
#logical error code will run but result is nonsensical
#value error give u non int format despite asking
#errors to know type error value error zeroerror name error and ioerror
#%%
try:
    "a"+"b"
except Exception:
    print("some error") #if the most strange and spec error add that first    
except ValueError:
    pass
except TypeError:
    print("Encounter Type Error") #(Most generic the last)
#always put the most stringent condition in the front and last resort at the end
#logic and sequence matters
#%%
#f string allows you to perform programming actions in the string itself
print(f"the result is {x*y}")





     
                

              
      

